#include<stdio.h>
main()
{
	float r,h,l,v,pi;
	pi=3.1415926;
	scanf("%f,%f",&r,&h);
	l=2*pi*r;
	v=pi*r*r*h;
	printf("l=%f\nv=%f",l,v);
}
