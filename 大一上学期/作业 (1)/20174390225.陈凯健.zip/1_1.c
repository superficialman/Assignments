#include<stdio.h>
main()
{
	int a,b,c,average;
	scanf("%d,%d,%d",&a,&b,&c);
	average=(a+b+c)/3;
		printf("average=%d",average);
}
