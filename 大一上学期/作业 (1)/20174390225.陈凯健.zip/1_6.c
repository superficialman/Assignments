#include<stdio.h>
#include<math.h>
main()
{
    float S,p,a,b,c,d;
    scanf("%f%f%f",&a,&b,&c);
    p=(a+b+c)/2.;
    d=p*(p-a)*(p-b)*(p-c);
    S=pow(d,0.5);
    printf("S=%f",S);

}
