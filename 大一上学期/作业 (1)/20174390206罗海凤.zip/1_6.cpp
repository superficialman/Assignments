#include<stdio.h>
main()
{
	float c,f;
	scanf("%f",&c);
	f=5.0/9*c+32;
	printf("%5.2f\n",f);
 } 
