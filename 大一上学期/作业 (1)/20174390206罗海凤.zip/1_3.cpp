#include<stdio.h>
main()
{
	char c;
	scanf("%c",&c);
	printf("\n%c",c);
 } 
