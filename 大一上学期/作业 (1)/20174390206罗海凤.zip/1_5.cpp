#include<stdio.h>
main()
{
	int a=3,b=4,c=5,x;
	x=(a+b+c)/3;
	printf("x=%d",x);
}
