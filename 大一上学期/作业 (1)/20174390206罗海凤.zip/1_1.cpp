#include"stdio.h"
main()
{
    int a=3,b=4,c;
    c=a;
    b=c;
    a=b;
    printf("%d","%d",a,b);
}
