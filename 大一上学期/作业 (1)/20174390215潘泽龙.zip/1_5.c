#include<stdio.h>
main()
{

   int c=50;
   float f;
      f=5/9*c+32;
    printf("%f",f);


}
