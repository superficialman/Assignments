#include<stdio.h>
main()
{
    char b,B;
    scanf("%c",&B);
        b=B;
            printf("%c",b);
}
