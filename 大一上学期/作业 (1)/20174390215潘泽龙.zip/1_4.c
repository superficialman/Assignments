#include<stdio.h>
main()
{
    int a=8,b=3;
     a=a^b;
        b=b^a;
         a=a^b;
          printf("a=%d,b=%d",a,b);

}
