#include<stdio.h>
main()
{
    float a=3.1415;
    int r,s,c,v,h;
        h=2,r=3;
        c=a*r*2;
        s=a*r*r;
        v=s*h;
        printf("%g",c,v);
}
