#include<stdio.h>
main()
{
    int a,b,c,d;
        a=5,b=9,c=2;
        d=(a+b+c)/3;
        printf("%d\n",d);
}
