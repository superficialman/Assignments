#include<stdio.h>
main()
{
    int a=7,b=5,c=9,p,s;

        p=(a+b+c)/2;

    d=sqrt(p*(p-a)*(p-b)*(p-c));

            printf("%d",d);


}
