#include "stdio.h"
main()
{ int c,f;
  c=36;
  f=5.0/9*c+32;
  printf("f=%d",f);
}
