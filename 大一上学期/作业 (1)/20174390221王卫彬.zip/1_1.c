#include<stdio.h>
main()
{
  float a,b,c,m;
  a=1.0;
  b=1.0;
  c=2.0;
  m=(a+b+c)/3.0;
  printf("m=%f",m);
}
