#include<stdio.h>
main()
{
  float a,b,c,p,d;
  double s;
  a=3.0;
  b=4.0;
  c=5.0;
  p=(a+b+c)/2.0;
  d=(p*(p-a)*(p-b)*(p-c));
  s=sqrt(d);
  printf("s=%d",s);
}
