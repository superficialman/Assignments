#include<stdio.h>
main()
{
  float r,h,a,c,v;
  a=3.14;
  r=1.0;
  h=2.0;
  c=2*r*a;
  v=r*r*h*a;
  printf("c=%f,v=%f",c,v);
}
