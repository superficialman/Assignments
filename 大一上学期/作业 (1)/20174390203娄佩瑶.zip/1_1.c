#include"stdio.h"
int main()
{
		int a,b,c;
		float s;
		scanf("%d%d%d",&a,&b,&c);
		s=(a+b+c)/3.0;
		printf("s=%f\n",s);
}