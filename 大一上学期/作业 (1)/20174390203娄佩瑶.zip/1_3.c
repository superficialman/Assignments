#include"stdio.h"
main()
{
	char c1,c2;
	scanf("%c",&c1);
	c2=c1+32;
	printf("\n%c",c2);
}