#include<stdio.h>
main()
{
    int a,b,c,p,s;
    scanf("%d,%d,%d",&a,&b,&c);
    p=(a+b+c)/2;
    s=sqrt(p*(p-a)*(p-b)*(p-c));
    printf("%d",s);
}
