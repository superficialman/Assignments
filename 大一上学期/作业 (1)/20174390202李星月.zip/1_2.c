#include <stdio.h>
main()
{
    float r,h,c,v;
    scanf("%f,%f",&r,&h);
    c=2*3.14*r;
    v=3.14*r*r*h;
    printf("%f,%f",c,v);
}
