#include<stdio.h>
main()
{
    char A,a;
    scanf("%c",&A);
    a=A+32;
    printf("%c",a);
}
