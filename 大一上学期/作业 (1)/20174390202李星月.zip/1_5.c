#include<stdio.h>
main()
{
    float c,f;
    scanf("%f",&c);
    f=5/9*c+32;
    printf("%f",f);
}
