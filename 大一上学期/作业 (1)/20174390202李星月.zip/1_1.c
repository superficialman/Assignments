#include<stdio.h>
main()
{   int a,b,c,d,e;
    scanf("%d,%d,%d",&a,&b,&c);
    d=a+b+c;
    e=d/3;
    printf("%d",e);
}
