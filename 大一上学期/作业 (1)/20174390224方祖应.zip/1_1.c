#include "stdio.h"
main()
{ 
  float a,b,c,x;
  a=1.0;
  b=1.0;
  c=2.0;
  x=(a+b+c)/3.0;
  printf("%f",x);
}
  