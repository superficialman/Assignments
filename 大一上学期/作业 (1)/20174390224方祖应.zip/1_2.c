#include "stdio.h"
main()
{
	float a,b,c,d,e;
	a=2.0;
	b=2.0;
    c=3.14;
	d=2*c*a;
	e=c*a*a*b;
	printf("%f,%f",d,e);
}