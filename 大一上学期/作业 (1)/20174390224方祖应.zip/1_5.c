#include"stdio.h"
main()
{
    float c,f;
    f=5/9*c+32;
    printf("%f",f);

}
