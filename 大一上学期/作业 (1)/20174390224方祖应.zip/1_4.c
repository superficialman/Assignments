#include "stdio.h"
main()
{
  float a,b,c,s,m;
  m=(a+b+c)/2.0;
  s=sqrt[m*(m-a)*(m-c)*(m-c)];
  printf(��s=%f",s);
}
