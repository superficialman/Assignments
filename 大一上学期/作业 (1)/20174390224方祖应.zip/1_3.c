#include"stdio.h"
main()
{
    float a,b,c;
    c=a;
    a=b;
    b=c;
    printf("%f,a,b");
}
