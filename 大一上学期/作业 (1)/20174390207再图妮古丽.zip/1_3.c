#include<stdio.h>
main()
{
	char A,B;
	A=97;
	B=98;
	printf("A=%c,B=%c",A,B);
}