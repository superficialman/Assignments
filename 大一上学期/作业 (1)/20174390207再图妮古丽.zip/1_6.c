#include<stdio.h>
main()
{
	int a,b,c;
	float p,s;
	scanf("%d %d %d",&a,&b,&c);
	p=(a+b+c)/2;
    s=(p*(p-a)*(p-b)*(p-c))e1/2;
		printf("s=%f",s);
}