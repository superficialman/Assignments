#include<stdio.h>
main()
{
	float c,f=0;
	scanf("%f",&c);
    f=5/9.*c+32;
		printf("f=%f",f);
}