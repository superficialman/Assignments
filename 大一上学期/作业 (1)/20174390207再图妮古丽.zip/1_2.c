#include<stdio.h>
main()
{
	float r,h,c,v,x;
	scanf("%f %f %f",&r,&h,&x);
	c=2*x*r;
	v=x*r*r*h;
	printf("%f %f\n",c,v);
}