#include<stdio.h>
main()
{
	int a,b,c;
	float x;
	scanf("%d %d %d",&a,&b,&c);
		x=(a+b+c)/3.;
		printf("%f\n",x);
}