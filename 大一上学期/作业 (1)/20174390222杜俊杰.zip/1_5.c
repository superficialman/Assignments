#include"stdio.h"
main()
{
    int a,b,c;
    a=1;
    b=2;
    c=a;
    a=b;
    b=c;
    printf("a=%d,b=%d",a,b);

}
