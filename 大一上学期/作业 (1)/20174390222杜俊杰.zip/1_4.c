#include"stdio.h"
main()
{
    float c,f:
        scanf("%d",&c)
        f=5/9*c+32

}
