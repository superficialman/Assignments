#include<stdio.h>
 main();
{
    int a，b，c;
	c=a;
	a=b;
	b=c;
	printf("%d\n,a,b)
}
