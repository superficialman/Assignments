#include<stdio.h>
main()
{ 
	int a,b;
    float c;
    scanf("%d %d %f",&a,&b,&c);
    printf("%f\n",(a+b+c)/3); 
}