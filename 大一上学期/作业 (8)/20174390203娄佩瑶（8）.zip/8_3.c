#include<stdio.h>
int isprim(int n)
{
    int i;
    if(n<2)
        return 0;
    for(i=2;i*i<=n;++i)
        if(n%i==0)
        return 0;  return 1;
}
int isssp(int n)
{
    if(!isprim(n))
        return 0;
    while(n/10)
        if(!isprim(n/=10))
        return 0;
    return 1;
}
main()
{
    int i,count=0,max;
    printf("��100-9999�ĳ��������У�");
    for(i=100;i<10000;++i)
    {
        if(isssp(i))
        {
            ++count;
            max=i;
            printf("%8d\n",i);
            if(count%5==0)
                printf("");
        }
    }
    printf("�ܹ��У�%d��\n",count);
    printf("����ǣ�%d",max);
    return 0;
}
