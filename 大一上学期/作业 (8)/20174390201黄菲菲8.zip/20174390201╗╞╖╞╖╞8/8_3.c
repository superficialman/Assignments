 #include<stdio.h>
int prime(int n)
{
	int i;
	for(i=2;i<n;i++)
		if(n%i==0)
			return 0;
		if(i==n)
			return 1;
		else
			return 0;
}
int fun(int n)
{
    int t,a;
    for(t=n;t>0;t=t/10)
    {
        if(prime(t))
           a=1;
        else
        {
            a=0;
            break;
        }
    }
    return a;
}
main()
{
	int i,count=0,max=0;
	for(i=100;i<10000;i++)
        if(prime(i)&&fun(i))
    {
        printf("%d\t",i);
	    count++;
	    if(max<i)
            max=i;
    }
    printf("������%d�����ֵ��%d",count,max);
}
