#include<stdio.h>
#include<math.h>
int superprime(int i)
{
	int j,f;
	while(i)
	{
		f=(i>1);
		for(j=2;j<=sqrt(i);f++)
		if(i%j==0){f=0;break;}
		if(!f)break;
		i/10;	
	}
	return f;
 } 
 main()
 {
 	int i,j,count=0;
 	for(i=100;i<=9999;i++)
 	{
 		if(superprime(i))
 		{
 			printf("%d\n",i);
 			count++;
 			printf("%d\n",count);
		 }
		 printf("%d\n",i);
	 }
 }
