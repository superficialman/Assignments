#include<stdio.h>
int fun(int s)
{
	int t,s1=10;
	t=s%10;
	while(s>10)
	{
		s=s/100;
		t=s%10*s1+t;
		s1*=10;
	}
	return t;
 } 
 main()
 {
 	int s,t;
 	printf("\nPlease enter s:");
 	scanf("%d",&s);
 	t=fun(s);
 	printf("The result is:%d\n",t);
 }
