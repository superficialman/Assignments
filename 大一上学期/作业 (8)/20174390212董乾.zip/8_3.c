#include<stdio.h>
int fun(int n)
{
	int i;
	if(n>1)
    {
        for(i=2;i<n;i++)
        if(n%i==0)
            return 0;
        return 1;
    }
    return 0;
}
int(chaojifun(int n))
{
    for(;n!=0;n/=10)
    {
        if(!fun(n))
            return 0;
    }
    return 1;
}
main()
{
    int x,count=0,max;
    for(x=100;x<=9999;x++)
    {
        if(chaojifun(x))
            {printf("%d\t",x);
            count++;
            max=x;
            }
    }
    printf("\n����Ϊ��%d\n��󳬼�����Ϊ��%d",count,max);
}
