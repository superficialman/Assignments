#include<stdio.h>
int main()
{
	int i,j,sum=0,a;
	for(i=1;i<=10;i++)
	{
		a=1;
		for(j=1;j<=i;j++)
			a*=j;
		sum+=a;
	}
	printf("sum=%d\n",sum);
	return 0;
}
