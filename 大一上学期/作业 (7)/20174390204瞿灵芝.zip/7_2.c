#include<stdio.h>
main()
{
    int i;
    float a=1.0,s=0;
    for(i=0;i<8;i++)
    {
        s=s+1.0/a;
        a=2*a;
    }
    a=765.0/s;
    printf("%.0f",a);
}
