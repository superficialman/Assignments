#include<stdio.h>
int fun(int n)
{
	if(n==1)
	  return 1;
	else
	  return n*fun(n-1); 
}
main()
{
	int a,sum=0;
	for(a=1;a<=10;a++)
	    sum=sum+fun(a);
	printf("%d\n",sum);
}
