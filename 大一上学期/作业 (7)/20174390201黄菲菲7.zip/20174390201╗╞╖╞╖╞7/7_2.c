#include<stdio.h> 
int fun(int i)
{
	int j,sum=0;
	for(j=0;j<8;j++)
	   sum=sum+i;
	   i=i*2;
	return sum;
}

main()
{
	int i;
	i=fun(1);
	if(765%i==0) 
	printf("%d\n",765/i);
}
	
