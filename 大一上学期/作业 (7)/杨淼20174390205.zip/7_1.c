#include<stdio.h>
main()
{
    int n,sum=0;
    for(n=1;n<=10;n++)
        sum+=jiecheng(n);
    printf("%d",sum);
}
int jiecheng(int a)
{
    int f;
    if(a==1)
        return 1;
    f=a*jiecheng(a-1);
    return("%d",f);
}
