#include<stdio.h>
float f(int x)
{
	int t;
	if(x==0||x==1)
		return 1;
	else
		t=f(x-1)*x;
	return t;
}
main()
{
	int n;
	float s=0;
	for(n=1;n<=10;n++)
	s=f(n)+s;
	printf("%f",s);
}

