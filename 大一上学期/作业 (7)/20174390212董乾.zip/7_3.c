#include<stdio.h>
#include<math.h>
float f(float x,float n)
{
    float s;
    int t;
    t=2*n;
    s=(float)pow((float)(-1),(float)n)*(float)pow((float)x,(float)t)/j(t);
    return s;
}
int j(int t)
{
    int h;
    if(t==0)
        h=1;
    else
        h=j(t-1)*t;
    return h;
}
float h(float x,float n)
{
    float s=0;
    for(;n!=0;n--)
        s=s+f(x,n);
    return s;
}
main()
{
    float x=5.6,y;
    int n=7;
    y=h(x,n)/(h(x+2.3,n)+h(x-3.2,n+3));
    printf("%f",y);
}
