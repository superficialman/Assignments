#include<stdio.h>
float f(float x)
{
	float s;
	if(x==1)
        s=1;
    else
    s=f(x-1)/2;
    return s;
}
main()
{
	float n=8,t=0,s;
	for(;n>=1;n--)
        if(n==0)
            t=1;
        else
            t=f(n)+t;
    s=766/t;
    printf("%f",s);
}
