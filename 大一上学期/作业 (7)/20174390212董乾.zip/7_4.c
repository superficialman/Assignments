#include<stdio.h>
float gs(float n)
{
    float S;
    S=2*2*n*n/((2*n-1)*(2*n+1));
    return S;
}
main()
{
    float s=1,k=10;
    for(;k!=0;k--)
        s=s*gs(k);
    printf("%f",s);

}
