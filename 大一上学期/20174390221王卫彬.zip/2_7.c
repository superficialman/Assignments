#include "stdio.h"
main()
{
 int i,a,b,c;
 scanf("%d",&i);
 if(i>999)
 printf("error");
 else
 {i=a*100+b*10+c;
 if(a>0) printf("3");
 else
  if(b>0) printf("2");
  else printf("3");
i=c*100+b*10+a;
printf("%d",i);
 }
}
