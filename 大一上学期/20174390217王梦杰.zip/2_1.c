#include "stdio.h"
main()
{
  char ch;
  scanf("%c",&ch);
  if
	  (ch>='a'&&ch<='z')
  {
	  ch=ch-32;
	  printf("%c",ch);
  }
  if
  (ch>='A'&&ch<='Z')
  {
	  ch=ch+32;
	  printf("%c",ch);
  }
  else
	  printf("input error\n");
}
