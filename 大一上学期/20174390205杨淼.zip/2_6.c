#include<stdio.h>
main()
{
   int grade,x;
   x=grade/10;
   scanf("%d",x);
   switch(x)
   {case 9:case 10:printf("A");break;
    case 8:printf("B");break;
    case 7:printf("C");break;
    case 6:printf("D");break;
    default:printf("E");
   }
}