#include<stdio.h>
main()
{   
  int b;
  scanf("%c",&b);
  if (b>=65&&b<=90)
	  printf("%c",b=b+32);
	  else (b>=97&&b<=122);
	  printf("%c",b=b-32);
}
