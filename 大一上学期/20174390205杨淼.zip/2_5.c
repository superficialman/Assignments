#include<stdio.h>
main()
{
   int x,y;
   printf("input x:");
   scanf("%d",&x);
   if(x>1)
	   if(x>=10)
		   y=3*x-11;
	   else
		   y=2*x-1;
   else
	   if(x<1)
		   y=x;
	   printf("%d",y);
}