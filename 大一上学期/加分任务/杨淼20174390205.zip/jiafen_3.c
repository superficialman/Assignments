#include<stdio.h>
int main()
{
    int i=0;
    for(;;i++)
    {
        if(i%5==1&&i%6==5&&i%7==4&&i%11==10)
        {
            printf("min result=%d\n",i);
            break;
        }
    }
    return 0;
}
