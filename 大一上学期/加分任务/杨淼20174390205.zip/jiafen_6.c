#include<stdio.h>
main()
{
    int i,j,k=5;
    for(i=1;i<=5;i++)
    {
        for(k=0;k<i;k++)
            printf(" ");
        for(j=5;j>=i;j--)
            printf("* ");
        printf("\n");
    }
    for(i=7;i<=10;i++)
    {
        for(j=10;j>=1;j--)
            printf("");
        for(j=6;j<=i;j++)
            printf("* ");
        printf("\n");
    }
}
