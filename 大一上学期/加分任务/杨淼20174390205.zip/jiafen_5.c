#include<stdio.h>
main()
{
    int a,b,c;
    for(a=0;a<=100;a++)
    {
        for(b=0;b<=100;b++)
        {
            int c=100-a-b;
            if((a+b+c==100)&&(5*a+3*b+c/3))
               {
                   printf("%d%d%d",a,b,c);
               }
        }
    }
    printf("%d%d%d",a,b,c);
}
