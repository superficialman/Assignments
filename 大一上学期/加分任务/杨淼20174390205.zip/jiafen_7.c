#include<stdio.h>
main()
{
    int a,b,c;
    for(a=1;a<=c;a++)
    {
        for(b=1;b<=c-a;b++)
            printf(" ");
        for(b=1;b<=a;b++)
            printf("%d",a-b);
            for(b=1;b<a;b++)
                printf("%d",a-b);
            printf("\n");
    }
    for(a=c-1;a>0;a--)
    {
        for(b=1;b<=c-a;b++)
            printf(" ");
        for(b=1;b<=a;b++)
            printf("%d",b);
        for(b=1;b<a;b++)
            printf("%d",a-b);
        printf("\n");
    }
}
