#include<stdio.h>
void main()
{
    int i,count=0;
    for(i=5;i<=1000;i=i+5)
    {
        if(i%5==0)
        {
            count++;
            if(i%25==0)
            {
                count++;
            }
            if(i%125==0)
            {
                count++;
            }
            if(i%625==0)
            {
                count++;
            }
        }
    }
    printf("The number of 0 in the end of 100! is:%d",count);
}
