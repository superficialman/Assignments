#include<stdio.h>
main()
{
    int a=0,count=0;
    while (a<=2017)
     {
         a=a+1;
         if(a%3==0&&a%5!=0)
    {
        count=count+1;
        printf("%5d",a);
    }
    else
        count=count+0;
     }
    printf("%d",count);
}

