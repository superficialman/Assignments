#include<stdio.h>
main()
{
    int a,b,c,d,e,f;
    scanf("%d",&a);
    b=a/1000;
    c=(a-b*1000)/100;
    d=(a-b*1000-c*100)/10;
    e=(a-b*1000-c*100-d*10);
    f=e*1000+d*100+c*10+b;
    printf("%d",f);

}
