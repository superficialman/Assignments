#include<stdio.h>
main()
{
  int a=1,s=0;
  while (a<=1000)
  {
      s=a+s;
      a=a+2;
  }
   printf("%d",s);
}
