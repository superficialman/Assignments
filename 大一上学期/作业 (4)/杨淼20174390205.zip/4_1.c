#include<stdio.h>
main()
{
    int a=0;
   while(a<1000)
   {
       a=a+1;
    printf("%5d",a);
   }

}
