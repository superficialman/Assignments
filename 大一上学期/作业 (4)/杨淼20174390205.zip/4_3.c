#include<stdio.h>
main()
{
    int year=0,count=0;
    while(year<2017)
    {
        year=year+1;
        if(year%4==0&&year%100!=0||year%400==0)
       {
          count=count+1;
          printf("%24d",year);
       }
         else count=count+0;
    }
    printf("%d\n",count);
}
