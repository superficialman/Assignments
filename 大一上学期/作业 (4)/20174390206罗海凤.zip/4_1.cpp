#include"stdio.h"
main()
{
	int n;
	n=0;
	while(n<=999)
	{
		n++;
		printf("%5d",n);
	}
 } 
