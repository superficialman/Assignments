#include<stdio.h>
main()
{ int year=1,count=0;
  while(year<2018) 
  {  if(year%4==0&&year%100!=0||year%400==0)
     { printf("%24d",year);
       count++; 
	 }
	 year++;
}
      printf("����%d������",count); 
  
}
