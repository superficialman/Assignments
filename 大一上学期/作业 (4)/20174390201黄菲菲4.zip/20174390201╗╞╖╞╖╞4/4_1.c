#include<stdio.h>
main()
{ 
  int i;
  i=0;
  while(i<=999)
  {
  	 i++;
  printf("%10d",i);
  }
 }
