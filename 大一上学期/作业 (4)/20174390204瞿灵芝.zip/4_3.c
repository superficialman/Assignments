#include<stdio.h>
main()
{
    int n=1,count=0;
    while(n<=2017)
    {
        if(n%4==0&&n%100!=0||n%400==0)
        count++;
        printf("%8d",n);
        n++;
        if(n%5==0)
            printf("\n");

    }
    printf("��Ԫ1��2017֮�����е�����",count);
}
