#include <stdio.h>
main()
{
    int i,count=0;
    while(i<=1000)
    {
        if(i%3==0&&i%5!=0)
        printf("%d\n",i);
        count++;
        i++;
    }
    printf("%d",i,count);

}
