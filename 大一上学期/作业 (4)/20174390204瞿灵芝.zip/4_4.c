#include<stdio.h>
main()
{
    int i;
    scanf("%d",&i);
    while(i!=0)
    {
        printf("%d",i%10);
        i=i/10;
    }

}
