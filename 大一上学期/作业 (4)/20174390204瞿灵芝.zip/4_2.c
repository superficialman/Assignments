#include<stdio.h>
main()
{
	int s=0,i=1;
	do{
		s+=i;
		i+=2;
	}while(i<=1000);
	printf("%d\n",s);
}
