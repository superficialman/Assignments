#include<stdio.h>
main()
{
	int i=0;
	while(i<1000)
	{
	    i++;
	    printf("%4d",i);
	}
}

