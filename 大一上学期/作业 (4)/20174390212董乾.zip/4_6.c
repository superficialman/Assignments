#include<stdio.h>
main()
{
    int x=1,c=0;
    while(x<=1000)
    {
        if(x%3==0&&x%5!=0)
        {printf("%d\t",x);
        c++;}
        x++;}
        printf("\n%d",c);
    }
