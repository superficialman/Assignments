#include<stdio.h>
main()
{
	int sum,a;
	a=1;
	sum=a;
	while(a<=499)
	{sum=sum+2*a+1;a=a+1;}
	printf("%d",sum);}
