#include<stdio.h>
main()
{
int n,i,m,c;
scanf("%d",&n);
i=n;c=0;
while(i>0)
{
	m=i%10;
	i/=10;
	c=m+c*10;
}
printf("%d",c);
}
