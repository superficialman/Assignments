#include<stdio.h>
main()
{
	int a;
	a=1;
	while(a<=1000)
	{printf("%d ",a);
	 a++;
    }
    }
