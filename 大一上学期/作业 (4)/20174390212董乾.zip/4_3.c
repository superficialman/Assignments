#include<stdio.h>
main()
{
	int y,c;
	y=1,c=0;
	while(y<=2017)
	{if(y%4==0&&y%100!=0||y%400==0)
	printf("%d		",y),c++;
	y++;}
	printf("\n%d",c);}

