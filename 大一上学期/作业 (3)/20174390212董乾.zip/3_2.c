#include<stdio.h>
main()
{
	int yy,mm,days;
	printf("input year and month:");
	scanf("%d %d",&yy,&mm);
	switch(mm)
	{
	case 1: case 3: case 5: case 7: case 8: case 10: case 12:printf("%d",days=31);break;
	case 4: case 6: case 9: case 11:printf("%d",days=30);break;
	case 2:
		{if(yy%4==0&&yy%100!=0||yy%400==0)printf("%d",days=29);
		else printf("%d",days=28);break;
	default:printf("input error");break;
		}
		printf("The days of%d%d is %d\n",yy,mm,days);
	}
}