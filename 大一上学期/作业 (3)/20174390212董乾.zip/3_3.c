#include<stdio.h>
main()
{
	int ma;
	float z,r,y;
	printf("��ѧ������:");
	scanf("%d",&ma);
	switch (ma/1000)
	{case 0:printf("%f\n%f\n%f\n",r=0,y=0,z=ma);break;
	 case 1:printf("%f\n%f\n%f\n",r=0.05,ma*0.05,ma*(1-0.05));break;
	 case 2:case 3:printf("%f\n%f\n%f\n",r=0.08,ma*0.08,ma*(1-0.08));break;
	 default:printf("%f\n%f\n%f\n",r=0.1,ma*0.1,ma*(1-0.1));}
}
