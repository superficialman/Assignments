#include<stdio.h>
main()
{
	int x;
	float y;
	scanf("%d",&x);
	switch(x/10)
	{case 0:printf("%f",y=x);break;
   	 case 1:printf("%f",y=x*2+3);break;
	 case 2:
     case 3:printf("%f",y=-0.5*x+10);break;
	 default:printf("Fail\n");}
}
	
