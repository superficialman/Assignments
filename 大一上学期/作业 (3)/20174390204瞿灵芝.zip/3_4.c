#include<stdio.h>
main()
{
    int a,b,c,d,min;
    scanf("%d,%d,%d,%d",&a,&b,&c,&d);
    printf("a=%d,b=%d,c=%d,d=%d\n",a,b,c,d);
    if(a>b)
        (min=b,b=a,a=min);
    if(a>c)
        (min=c,c=a,a=min);
    if(a>d)
        (min=d,d=a,a=min);
    if(b>c)
        (min=c,c=b,b=min);
    if(b>d)
        (min=d,d=b,b=min);
    if(c>d)
        (min=c,d=c,c=min);
    printf("��С���������:%d,%d,%d,%d\n",a,b,c,d);



}
