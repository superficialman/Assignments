#include<stdio.h>
main()
{
	int n;
	scanf("%d",&n);
	if(n%3==0&&n%4==0&&n%5==0)
		printf("Yes");
	else
		printf("No");
}