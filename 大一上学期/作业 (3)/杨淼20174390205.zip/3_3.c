#include<stdio.h>
main()
{
  float ma,tr,y,s;
  printf("���뽱��");
  scanf("%f",&ma);
  switch((int)ma/1000)
  {
  case 0:tr=0;break;
  case 1:tr=0.05;break;
  case 2:tr=0.08;break;
  default:tr=0.1;break;
  }
  y=tr*ma;
  s=ma-y;
  printf("%f%f%f",tr,y,s);
}
