#include<stdio.h>
main()
{
    int x,y;
    scanf("%d",&x);
    switch (x)
    {
        case 1:printf("%d",y=x);break;
        case 2:printf("%d",y=x*2+3);break;
        case 3:printf("%d",y=-0.5*x+10);break;
        default:printf("input error");

    }

}
