#include<stdio.h>
main()
{
    int y,m,day;
    printf("input year and month");
    scanf("%d%d",&y,&m);
    switch(m)
    {
        case 1:case 3:case 5:case 7:case 8:case 10:case 12:day=31;break;
        case 4:case 6:case 9:case 11:day=30;break;
        case 2:if(y%4==0&&y%100!=0||y%400==0)printf("%d",day=29);
               else day=28;
               break;
        default:printf("input error");break;
    }
    printf("the day of%d%d is %d\n",y,m,day);
}
