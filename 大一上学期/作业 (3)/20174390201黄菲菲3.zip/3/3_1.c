#include<stdio.h>
main()
{
	float x,y;
	scanf("%f",&x);
	switch((int)x/10)
	{     case 0:printf("y=x",y);break;
	case 1:printf("y=x*2+3",y);break;
	case 2: case 3:printf("y=-0.5*x+10",y);
	}
	printf("y=%f",y);
}
