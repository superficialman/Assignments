#include"stdio.h"
main()
{  float ma,tr,y,s;
  printf("�����뽱��");
  scanf("%f",&ma);
  switch ((int)ma/1000)
  {  case 0: tr=0;break;
     case 1:tr=0.05;break;
     case 2:
     case 3: tr=0.08;break;
     default:tr=0.1;break;
  }
  y=tr*ma ;
  s=ma-y;
  printf("˰�ʣ�%.2f,˰�%.2f,ʵ�ý���%.2f",tr,y,s);
}
