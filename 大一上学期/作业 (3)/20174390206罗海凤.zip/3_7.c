#include"stdio.h"
main()
{
	int yy;
	printf("input year");
	scanf("%d",&yy);
	switch(yy%4==0&&yy%100!=0||yy%400==0)
	{
	case 1:printf("YES");break;
	case 0:printf("NO");break;
	default:printf("error");
	}
}
