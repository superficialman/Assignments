#include"stdio.h"
main()
{
	int n;
	printf("input n"); 
	scanf("%d",&n);
	switch(n%3==0&&n%4==0&&n%5==0)
		{ 
		case 1:printf("YES");break;
		case 0:printf("NO");break;
		default:printf("error"); 
	    }
}
