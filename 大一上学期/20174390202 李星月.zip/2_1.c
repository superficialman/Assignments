#include<stdio.h>
main()
{
    char character;
    scanf("%c",&character);
    if(character>=65&&character<=90)
        printf("%c\n",character=character+32);
    else printf("%c\n",character=character-32);
}
