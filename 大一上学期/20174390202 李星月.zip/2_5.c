#include<stdio.h>
main()
{
    int x,y;
    scanf("%d",&x);
    if(x<1)
        printf("%d\n",y=x);
    if(x>=1&&x<10)
        printf("%d\n",y=2*x-1);
    if(x>=10)
        printf("%d\n",y=3*x-11);
}
