#include<stdio.h>
main()
{
    int a,i,count=0;
    for(a=2;a<=10000;a++)
    {
        for(i=2;i<=a/2;i++)
            if(a%i==0) break;
        if(i>a/2)
        {
            printf("%5d",a);
            count++;
        }
    }
    printf("����Ϊ%d",count);
}
