#include<stdio.h>
main()
{
    int num,n=0;
    for(num=1000;num<9999;num++)
    {
        if(num%4==0&&num%10==6)
        {
            n+=1;
        }
    }
    printf("%d",n);
}
