#include<stdio.h>
main()
{
    int x,y,z,n,count=0;
    printf("ˮ�ɻ�����:\n");
    for(n=1;n<=10000;n++)
    {
        x=n/100;
        y=(n-x*100)/10;
        z=n-x*100-y*10;
        if(n==(x*x*x+y*y*y+z*z*z))
        {
            printf("%d\t",n);
            count++;
        }
    }
    printf("\n count=%d",count);
}
