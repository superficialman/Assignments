#include<stdio.h>
main()
{
    int i,j,k,count=0;
    for(i=0;i<3;i++)
    {
        for(j=0;j<5;j++)
        {
            for(k=0;k<6;k++)
            {
                if(i+k+j==5)
                    count++;
            }
        }
    }
    printf("%d",count);
}
