#include<stdio.h>
main()
{
    char t;
    int i1=0,i2=0,i3=0;
    do
    {
        scanf("%c",&t);
        if(t=='\n') break;
        else
        {
            if((t>='A'&&t<='Z')||(t>='a'&&t<='z'))
                i1++;
            if(t==' ')
                i2++;
            if(t>='0'&&t<='9')
                i3++;

        }

    }
    while(1);
        printf("�ַ�����Ϊ:%d,�ո����Ϊ:%d,���ָ���Ϊ��%d",i1,i2,i3);
}
