#include<stdio.h>
main()
{ int a,i,m,number=0,max=0;
 for(a=1;a<=1000;a++)
 {  m=0;
	for(i=1;i<=a/2;i++)
    if(a%i==0) m=m+i;
	 if(m==a) { number++;printf("%d\n",a); max=m;}
  }
  printf("number is %d, max is %d\n", number, max);
}
