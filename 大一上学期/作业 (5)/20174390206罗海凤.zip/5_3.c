#include<stdio.h>
main()
{int i,sum=0,count;
count=0;
for(i=1000;i<10000;i++)
if(i%4==0&&i%10==6)
{sum=sum+i;
count++;}
printf("count:%d,sum:%d\n",count,sum);
}
