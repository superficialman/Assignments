#include<stdio.h>
main()
{
int i,j,k;
  printf("\n hong bai hei\n");
 for(i=0;i<=3;i++)
    for(j=1;j<=5;j++)
    {  k=6-i-j;
       if(k>=0) printf(" %3d %3d %3d\n",i,j,k);
    }
}
