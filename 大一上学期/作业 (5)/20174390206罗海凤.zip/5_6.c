#include<stdio.h>
#include<math.h>
main()
{  double pi=0,i=1,j=1,k;
   do
{
    k=i/j;
	 pi=pi+k;
	 i=-i;
    j=j+2;
 }while (fabs(k)>1.0e-6);
   printf("pi is %lf",4*pi);
}
