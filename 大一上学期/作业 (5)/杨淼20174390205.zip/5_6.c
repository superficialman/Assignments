#include<stdio.h>
#include<math.h>
main()
{
    double sum=0,i=1,j=1,k;
    do
    {
        k=i/j;
        sum=sum+k;
        i=-i;
        j=+2;
    }
    while(fabs(k)>1.0e-6);
    printf("sum is %if",4*sum);
}
