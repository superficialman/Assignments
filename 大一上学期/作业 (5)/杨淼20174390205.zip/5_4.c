#include<stdio.h>
main()
{
    int i,j,k;
    for(i=1;i<=3;i++)
    for(j=1;j<=5;j++)
    for(k=1;k<=6;k++)
    if(i+j+k==6&&j!=0)
    printf("%2d%d%d",i,j,k);
}
