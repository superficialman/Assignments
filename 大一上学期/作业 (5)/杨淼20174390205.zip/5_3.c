#include<stdio.h>
main()
{
    int a,count=0,sum=0;
    for(a=1000;a<=9999;a++)
        if(a%4==0&&a%10==6)
        {count=count+1;
           sum=sum+a;

    }
    printf("%5d%5d",sum,count);
}
