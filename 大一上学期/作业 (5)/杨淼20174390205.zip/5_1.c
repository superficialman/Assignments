#include<stdio.h>
main()
{
    int unit,ten,hundred,n;
    for(n=100;n<1000;n++)
    {
        hundred=n/100;
        ten=n/10-hundred*10;
        unit=n%10;
        if(n==unit*unit*unit+ten*ten*ten+hundred*hundred*hundred)
            printf("%6d",n);
    }
}
