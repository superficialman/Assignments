#include<stdio.h>
main()
{
    int a,b,count=0;
    for(a=2;a<=10000;a++)
    {
        b=2;
        while(a%b!=0&&b<=a-1)
            b++;
        if(a==b)
        {
            printf("%5d",a);
            count++;
        }
    }
    printf("\ncount=%d",count);
}
