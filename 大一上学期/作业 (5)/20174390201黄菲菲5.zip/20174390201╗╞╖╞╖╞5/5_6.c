#include<stdio.h>
main()
{ int i;
  double sum=0;
  for(i=1;;i=i+2)
    { if(i%2==0) sum=sum-1.0/(2*i-1);
      else sum=sum+1.0/(2*i-1);
      if(1.0/(2*i-1)<10e-6) break;
	 } 
	 printf("%f",sum); 
}
