#include<stdio.h>
main()
{ int n,a,b,c,count;
  for(n=2;n<=1000;n++)
  {  a=n/100;
     b=n/10%10;
	 c=n%10; 
	 if(n==c*c*c+b*b*b+a*a*a) 
	   {
	   printf("%5d",n);
	   count++;}
}
	 printf("�ܹ�%d",count);
}
