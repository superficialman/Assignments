#include<stdio.h>
main()
{ int n,a,b,c,d=6,sum=0,count=0;
  for(n=1000;n<=9999;n++)
  {   c=n/10%10;
      b=n/100%10;
      a=n/1000;
	 if(n%4==0)
	 {sum=sum+n;
		 count++;}
   } 
	 printf("�ܹ�%d��,�ܺ�Ϊ%d",count,sum);

}
