#include<stdio.h>
main()
{
    int n=1;
    float a,sum=0;
    do
    {
        a=(float)1/(2*n-1);
        if(n%2==1)
            sum+=a;
        else
            sum-=a;
        n++;
    }
    while(a>=0.000001);
    printf("pi=%f\n",sum*4);
}
