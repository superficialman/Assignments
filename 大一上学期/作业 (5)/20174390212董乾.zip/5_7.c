#include<stdio.h>
main()
{
    char ch;
    int a=0,b=0,c=0;
    while((ch=getchar())!='\n')
        if(ch==' ')
            a++;
        else if(ch>='A'&&ch<='z')
            b++;
        else if(ch>='0'&&ch<='9')
            c++;
    printf("�ո�ĸ���Ϊ:%d\n",a);
    printf("��ĸ�ĸ���Ϊ:%d\n",b);
    printf("���ֵĸ���Ϊ:%d\n",c);
}
