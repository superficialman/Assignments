#include<stdio.h>
main()
{
    int a,count=0,sum=0;
    for(a=1000;a<=9999;a++)
        if(a%4==0&&a%10==6)
    {
        count++;
        sum=sum+a;
    }
    printf("%d",count);
    printf("\n%d",sum);
}
