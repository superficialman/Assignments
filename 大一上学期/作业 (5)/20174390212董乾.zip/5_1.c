#include<stdio.h>
main()
{
	int a,b,c,d,n,count=0;
    for(n=100;n<1000;n++)
	{a=n%10;b=n/10%10;c=n/100%10;d=n/1000%10;
	 if(n==c*c*c+b*b*b+a*a*a)
    {printf("%d\n",n);
    count++;
	 }
	}
	for(n=1000;n<10000;n++)
	{a=n%10;b=n/10%10;c=n/100%10;d=n/1000%10;
	 if(n==d*d*d*d+c*c*c*c+b*b*b*b+a*a*a*a)
	{printf("%d\n",n);
	count++;
	 }
	}
	printf("%d\n",count);
}



