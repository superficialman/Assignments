#include<stdio.h>
main()
{
	int n,i,count=0;
	for(n=2;n<=10000;n++)
    {
        for(i=2;i<=n/2;i++)
            if((n%i)==0) break;
        if(i>(n/i))
           {printf("%d\t",n);
            count++;}
    }
    printf("\n%d\n",count);
}
