#include "stdio.h"
main()
{
 int n,a,b,c;
 scanf("%d",&n);
 if(i>=1000)
 printf("error");
 else
 {n=a*100+b*10+c;
 if(a>0)
 printf("3");
 else
  if(b>0)
  printf("2");
  else
  printf("3");
n=c*100+b*10+a;
printf("%d",n);
 }
}
