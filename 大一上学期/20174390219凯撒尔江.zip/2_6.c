#include<stdio.h>
main()
{
  int x;
  scanf("%d",&x);
  switch(x/10)
  {
  case10:printf("A");break;
  case9:printf("A");break;
  case8:printf("B");break;
  case7:printf("C");break;
  case6:printf("D");break;
  default:printf("E");break;
  }
}
