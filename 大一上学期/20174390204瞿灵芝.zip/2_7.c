#include<stdio.h>
main()
{
	int a,b,c,d;
	a>=0;
	b>=0;
	c>=0;
	d>=0;
	d=a*100+b*10+c;
	if(a=0)
	  {
	      if(b=0)
	      printf("1");
	      else
	      printf("2");}
	      else
	      printf("3");
	      d=c*100+b*10+a;
	      printf("%d",d);
}

