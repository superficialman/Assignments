#include<stdio.h>
int Gcd(int a,int b);
int main()
{
    int m,n;
    int k;
    scanf("%d%d",&m,&n);
    k=Gcd(m,n);
    printf("%d",k);
    return 0;
}
int Gcd(int a,int b)
{
    int s,tem;
    if(b==0)
    {
        s=a;
    }
    else
    {
        s=Gcd(b,a%b);
    }
    return s;
//  return
}
