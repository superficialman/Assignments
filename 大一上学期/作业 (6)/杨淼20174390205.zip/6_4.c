#include<stdio.h>
int fun(int c)
{
    int a,b;
    for(a=1;a<c;a++)
        for(b=1;b<c;b++)
            if(a*a+b*b==c*c)
                return 1;
        return 0;

}
main()
{
    int a,b,c,counter=0;
    for(c=1;c<=1000;c++)
    {
        if(fun(c))
        {
            printf("%d\t",c);
            counter++;
        }

    }
     printf("1000���ڹ���%d������",counter);
}
