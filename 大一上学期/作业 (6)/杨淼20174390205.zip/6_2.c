#include<stdio.h>
int prime(int n);
main()
{
    int n,count=0;
    for(n=1000;n<=10000;n++)
        if(prime(n))
    {
        printf("%d\t",n);
        count++;
        if(count%6==0)
            printf("\n");
    }
    printf("\n%d",count);
}
int prime(int n)
{
    int i;
    for(i=2;i<=10000;i++)
        if(n%i==0)
        break;
    if(i==n)
        return 1;
    return 0;
}
