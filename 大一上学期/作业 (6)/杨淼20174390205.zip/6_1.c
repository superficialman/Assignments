#include<stdio.h>
int add(int a,int b);
main()
{
    int a=1,b=2;
    printf("a+b=%d\n",add(a,b));
}
int add(int a,int b)
{
    return a+b;
}
