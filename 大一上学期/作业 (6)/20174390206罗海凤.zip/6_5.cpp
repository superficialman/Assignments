#include "stdio.h" 
int funx(int n) 
{
    int i,s=1;
    for(i=1;i<=n;i++)
        s=s*i;
    printf("%d\n",s);
    return 0;
}

long fun(int x)
{ long p=1; int i,n;
  for (i=1;i<=n;i++)
     p*=x;
return p;
}
void main()
{
	int n,x,s=1;
	s=s+fun(x)/funx(n);
	printf("%d",s);
}