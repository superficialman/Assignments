#include<stdio.h>
int add(int x,int i)
{
	int a=0;
	scanf("%d",&x);
	for(i=2;i<x;i++)
	{
	if(x%i==0)
	{a++;}
    }
    if(a==0)
    {
	printf("YES");
    }
	else
	{
	printf("NO");
    }
    return 0;
}

main()
{
    int i,j,count=0;
    for(i=1000;i<=10000;i++)
    {
        for(j=2;j<i;j++)
        {
            if(i%j==0)
			{
				break;
            }
        }
        if (i==j)
		{
        	count++;
			printf("%5d",i);
        }
    }
    printf("\n%d\n",count);
}