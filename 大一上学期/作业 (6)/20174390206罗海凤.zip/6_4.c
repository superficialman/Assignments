#include<stdio.h>
int fun(int a,int b,int c)
{
	if(a*a+b*b==c*c||a*a+c*c==b*b||c*c+b*b==a*a)
		return 1;
	else
		return 0;
}

main()
{
    int a,b,c,count=0,i;
    for(a=1;a<1000;a++)
    {
		for(b=1;b<1000;b++)
		{
			for(c=1;c<1000;c++)
			{
				if(fun(a,b,c))
				{	
				    if(a!=b&&a!=c&&b!=c)
				    {
					count++;
					printf("%5d%5d%5d\n",a,b,c);
				    }
			    }
			}
		}
	}
	printf("\n%d\n",count);
}
