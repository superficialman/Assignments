#include<stdio.h>
int add(int x,int y) 
{ 
scanf("%d%d",&x,&y);
int n=x;
if (n>y)
       n=y;
       for(int i=n;i>=1;i--)
{
       if (x%i==0&&y%i==0)
       {
              printf("���Լ����%d \n",i);
              break;
       }
	   return 0;
}
} 

#include<stdio.h>
void main() 
{ 
printf("please input two number:\n");
int a,b;
scanf("%d%d",&a,&b);
int n=a;
if (n>b)
       n=b;
       for(int i=n;i>=1;i--)
{
       if (a%i==0&&b%i==0)
       {
              printf("���Լ����%d \n",i);
              break;
       }
}
} 