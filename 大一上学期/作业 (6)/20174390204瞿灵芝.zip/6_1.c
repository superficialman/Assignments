#include<stdio.h>
int add(int a,int b)
{
	return a+b;
}
main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	printf("a+b=%d\n",a+b);
}