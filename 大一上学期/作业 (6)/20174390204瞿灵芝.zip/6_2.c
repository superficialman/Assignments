#include<stdio.h>
int prime(int n)
{
	int i;
	for(i=2;i<n;i++)
		if(n%i==0)
			break;
		if(i==n)
			return 1;
		else
			return 0;
}
int main()
{
	int i,count=0;
	for(i=1000;i<=10000;i++)
	if(prime(i)==1)
	{
		printf("%d\t",i);
		count++;
		if(count%6==0)
			printf("\n");
	}
		printf("�ܸ����ǣ�%d\n",count);
}
