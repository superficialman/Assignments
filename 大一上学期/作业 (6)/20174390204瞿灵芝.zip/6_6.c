#include<stdio.h>
int prime(int n)
{
    int i;
    for(;n>0;)
    {
        i=n%10;
        n=n/10;
        printf("%d",i);
    }
}
main()
{
    int n,x;
    printf("input:");
    scanf("%d",&n);
    x=prime(n);
}
