#include<stdio.h>
#include<math.h>
int factorial(int n)
{
    int f=1;
    while(n>=1)
        f=f*n--;
    return f;
}
int prime(int x,int n)
{
    int s;
    s=pow(x,n);
    return s;
}
main()
{
    double s=0;
    int x,n;
    printf("input:");
    scanf("%d,%d",&x,&n);
    for(;n>=0;n--)
        s+=(double)prime(x,n)/(double)factorial(n);
    printf("s=%f\n",s);
}
