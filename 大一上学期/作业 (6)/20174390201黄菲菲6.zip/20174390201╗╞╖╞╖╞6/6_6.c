#include<stdio.h>
int fun(long x)
{
    long y;
    for(y=0;x>0;x=x/10)
        y=y*10+x%10;
    printf("%ld\n",y);
    getch();
    return 0;
}
main()
{
    long n;
    scanf("%d",&n);
    printf("%d",fun(n));
}
