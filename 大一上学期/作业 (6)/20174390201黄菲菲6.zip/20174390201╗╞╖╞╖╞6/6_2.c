#include<stdio.h>
int prime(int n)
{
	int i;
	for(i=2;i<n;i++)
		if(n%i==0)
			break;
	    if(i==n)
		    return 1;
 	    else
		    return 0;
}
main()
{
	int n,count=0;
	for(n=1000;n<=10000;n++)
		if(prime(n))
		{
		count++;
		printf("%8d",n);
		if(count%6==0)
		printf("\n");
		}
	printf("\ntotal number is%d",count);
}
