#include<stdio.h>
 int fun(int n)
 {
     int i,j;
     for(i=1;i<1000;i++)
     {
         for(j=1;j<1000;j++)
         {
             if(n*n==i*i+j*j&&n!=i&&n!=j)
                continue;
         }
     }
     return 1;
 }
 main()
 {
     int i,count=0;
     for(i=1;i<1000;i++)
     {
         if(fun(i))
         {
             printf("%d\t",i);
             count++;
         }
     }
     printf("The total number is%d",count);
 }
