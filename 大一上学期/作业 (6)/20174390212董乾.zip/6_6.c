#include<stdio.h>
int ny(int n)
{
    int s=0;
    for(;n;)
        {
            s=n%10+s*10;
            n=n/10;
        }
    return s;
}
main()
{
    int n;
    scanf("%d",&n);
    printf("%d",ny(n));
}
