#include<stdio.h>
int add(int x,int y)
{
    int s;
    s=x+y;
    return s;
}
main()
{
    int a,b,c;
    scanf("%d %d",&a,&b);
    c=add(a,b);
    printf("%d",c);
}
