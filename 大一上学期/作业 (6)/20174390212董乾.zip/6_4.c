#include<stdio.h>
int xs(int a)
{
    int b,c;
    for(b=1;b<a;b++)
        for(c=1;c<a;c++)
            if(a*a>=b*b+c*c)
               if(a*a==b*b+c*c)
                  return a;
    return 0;
}
main()
{
    int n,count=0;
    for(n=1;n<=1000;n++)
        if(xs(n))
        {printf("%d\t",n);
         count++;}
         printf("\n%d",count);
}
