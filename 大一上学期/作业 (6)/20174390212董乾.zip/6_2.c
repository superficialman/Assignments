#include<stdio.h>
int prime(int n)
{
    int i;
    for(i=2;i<n;i++)
        if(n%i==0)
        break;
    if(i==n)
        return 1;
    else
        return 0;
}
main()
{
    int m,count=0;
    for(m=1000;m<=10000;m++)
        if(prime(m))
    {
        printf("%d\t",m);
        count++;
        if(count%6==0)
            printf("\n");
    }
    printf("\n%d\n",count);
}
