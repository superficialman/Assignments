#include <stdio.h>
main()
{
	char letter;
	scanf ("%d",&letter);
	if(65<=letter&&letter<=90)
		letter=letter+32;
	else if(97<=letter&&letter<=122)
		letter=letter-32;
	printf("letter=%d\n",letter);
}