#include <stdio.h>
main()
{
	int x,y,num;
	scanf("%d",&x);
	if (x<=0||1000<=x)
		printf("illegal input!");
	if  (x>0&&x<10)
		num=1;
	    y=x;
	if  (10<=x&&x<100)
		num=2;
	    y=x/10+(x-(x/10)*10);
	if  (100<=x&&x<1000)
		num=3;
	    y=x/100+(x-x/100*100)/10*10+(x-x/100*100-(x-x/100)/10*10)*100;
		printf("num=%d\nx=%y=%d\n",num,x,y);
}
