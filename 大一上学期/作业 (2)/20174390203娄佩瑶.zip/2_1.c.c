#include<stdio.h>
main()
{     char  c;
      printf("input a word\n");
      scanf("%c",&c);
	  if(c>='A'&&c<='Z')
		  printf("%c\n",c+32);
	  if(c>='a'&&c<='z')
		  printf("%c\n",c+32);
}