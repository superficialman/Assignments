#include<Stdio.h>
int main()
{
	int a,ans1,g,s,b,ans3;
	scanf("%d",&a);
	if(a>9&&a<100) ans1=2;
	else if(a>99) ans1=3;
	else if(a<10)  ans1=1;

	g=a%10;
	s=((a-g)/10)%10;
	b=a/100;

	ans3=g*100+s*10+b;

	printf("%d %d %d %d %d\n",ans1,b,s,g,ans3);
}
