#include<stdio.h>
main()
{
        int a,b,c,d,e,f;
        scanf("%d",&a);
        if(a<1000&&a>=100)
		{	b=3;
         printf("%d\n",b);
		}
        else if(a<100&&a>=100)
		{	b=2;
		printf("%d\n",b);
		}
		else if(a>0&&a<10)
		{	b=1;
		printf("%d\n",b);
		}
        if(b==3)
		{   c=a/100;
	    	d=a/10-10*c;
	    	e=a-100*c-10*d;
	    	f=100*e+10*d+c;
		printf("%d %d %d %d\n",c,d,e,f);
		}
		else if(b==2)
		{      d=a/10;
		       e=a-10*d;
			   f=10*e+d;
			printf("%d %d %d\n",d,e,f);
		}
			else if(b==1)
		{       e=e;
			    f=f;
			printf("%d %d\n",e,f);
		}
}



