#include<stdio.h>
main()
{
	float x,y;
	scanf("%f",&x);
	if(x<10)
		if(x<1)
		     y=x;
		else
		     y=x*2-1;
     else
	 if(x>=10)
		 y=x*3-11;
	 printf("y=%f\n",y);
}
