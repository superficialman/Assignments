#include<stdio.h>
main()
{
	char a,b;
	scanf("%c %c",&b,&a);
	      a=b+32
        	If(scanf("%c",&b))
        	printf("%c\n",a);
	else	If(scanf("%c",&a))
        	printf("%c\n",b);
}
