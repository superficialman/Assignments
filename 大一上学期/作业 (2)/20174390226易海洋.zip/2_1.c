#include<stdio.h>
main()
{
	char c;
	printf("input a character:");
	scanf("%c",&c);
		if(c>='A'&&c<='Z')
			c=c+32;
		else c=c-32;
		printf("%c\n",c);

}
