#i,nclude<stdio.h>
main()
{
    int a=8,b=7,c=9,t=0;
    if(a<b) t=a;a=b;b=t;
    if(a<c) t=a;a=c;c=t;
    if(b<c) t=b;b=c;c=t;
    printf("%5d%5d%5d\n",a,b,c);
}
