#include<stdio.h>
main()
{
    int number,a,b,c,d;
        scanf("%d",&number);
    if(number<10)
    {printf("һλ��\n��λ:%d\n%d",number,number);}
        else if(number>=10&&number<100)
        {
            a=number/10;
            b=number%10;
            c=b*10+a;
            printf("��λ��\n��λ:%d ʮλ:%d\n%d",b,a,c);}
        else if(number>=100&&number<=999)
        {
            a=number/100;
            b=(number-a*100)/10;
            c=number-a*100-b*10;
            d=a+b*10+c*100;
            printf("��λ��\n��λ:%d ʮλ:%d ��λ:%d\n%d",c,b,a,d);}

}
