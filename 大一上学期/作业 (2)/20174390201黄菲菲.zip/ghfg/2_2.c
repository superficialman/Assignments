#include"stdio.h"
main()
{
	int a=1,b=2,c=3,d=4;
	if(a<b<c)
		printf("%d\n",d);
	else
		if((c-b)==a)
			printf("%d\n",2*d);
		else
			printf("%d\n",4*d);
}
