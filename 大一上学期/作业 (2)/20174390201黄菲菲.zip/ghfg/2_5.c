#include"stdio.h"
main()
{ 
	float x,y;
	scanf("%f",&x);
	if(x<1) printf("y=x",y);
	if(1<=x<10) printf("y=2*x-1",y);
	if(x>=10) printf("y=3*x-11",y);
}