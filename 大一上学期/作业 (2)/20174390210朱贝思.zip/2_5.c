#include<stdio.h>
main()
{
    int x,y;
    printf("input x:");
    scanf("%d",&x);
    if(x<10)
        if(x<1)
            y=x;
        else
            y=2*x-1;
    else
        y=3*x-11;
    printf("y=%d",y);
}
