#include<stdio.h>
main()
{
	char letter;
	printf("enter an english letter:");
	scanf("%c",&letter);
	if(65<=letter&&letter<=90)
		letter=letter+32;
	else
		if(97<=letter&&letter<=122)
		letter=letter-32;
	printf("letter=%c\n",letter);
}