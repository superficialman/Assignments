#include<stdio.h>
main()
{
    int x,y,number;
 �  printf("enter a number:");
    scanf("%d",&x);
  � if(x<=0||x>=1000)
       printf("illegal input!");
      �if(x>0&&x<10)
          number=1;
           y=x;
         if(x>=10&&x<100)
            number=2;
            y=x/10+(x-(x/10)*10);
            if(x>=100&&x<1000)
                number=3;
            y=x/100+(x-x/100*100)/10*10+(x-x/100*100-(x-x/100*100)/10*10)*100;
    printf("num=%d x=%d y=%d\n",number,x,y);
}
