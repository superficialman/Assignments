#include"stdio.h"
main()
{int a,b,c,x;
scanf("%d",&x);
a=x/100;
b=(x%100)/10;
c=x%10;
if (a!=0) printf("��λ��,%d,%d,%d,%d%d%d",a,b,c,c,b,a);
else if(b!=0) printf("��λ��,%d,%d,%d%d",b,c,c,b);
else printf("һλ��,%d,%d",c,c);
}
