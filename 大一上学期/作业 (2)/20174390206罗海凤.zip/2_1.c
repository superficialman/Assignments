#include"stdio.h"
main()
{
	char c;
	scanf("%c",&c);
	if(c>=65&&c<=90)
		printf("%c\n",c=c+32);
	else
		printf("%c\n",c=c-32);
}