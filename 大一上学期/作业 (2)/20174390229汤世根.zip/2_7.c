#include<stdio.h>
main()
{
    int k,a,b,c,d;
        scanf("%d",&k);
    if(k<10)
    {printf("һλ��\n��λ:%d\n%d",k,k);}
        else if(k>=10&&k<100)
        {
            a=k/10;
            b=k%10;
            c=b*10+a;
            printf("��λ��\n��λ:%d ʮλ:%d\n%d",b,a,c);}
        else if(k>=100&&k<=999)
        {
            a=k/100;
            b=(k-a*100)/10;
            c=k-a*100-b*10;
            d=a+b*10+c*100;
            printf("��λ��\n��λ:%d ʮλ:%d ��λ:%d\n%d",c,b,a,d);}

}
