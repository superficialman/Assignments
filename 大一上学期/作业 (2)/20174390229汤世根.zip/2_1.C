#include<stdio.h>
main()
{
char ch;
scanf("%c",&ch);
if(ch>='A'&&ch<='Z')
{ch=ch+32;
}
else
{ch=ch-32;}
printf("ch=%c",ch);
}