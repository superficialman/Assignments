#include<stdio.h>
main()
{
	char a;
    printf("input a letter\n");
	scanf("%c",&a);
	if(a>=65&&a<=90)
	{  a=a+32;	
    printf("%c",a);}
	if(a>=97&&a<=122)
	{	a=a-32;
	printf("%c",a);}
	if(a<65||a>122)
	printf("error\n");
}