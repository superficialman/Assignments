#include<stdio.h>
main()
{
    int x;
    printf("������ ѧ���ɼ�\n");
    scanf("%d",&x);
    if(x>100||x<0)
        printf("score is error.");
    switch(x/10)
    {
    case 9:printf("A");break;
    case 8:printf("B");break;
    case 7:printf("C");break;
    case 6:printf("D");break;
    default:printf("E");
    }
    return 0;
}
